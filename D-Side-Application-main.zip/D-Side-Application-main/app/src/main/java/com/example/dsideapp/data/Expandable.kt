package com.example.dsideapp.data

class Expandable(val title: String, val description: String, var isExpandable: Boolean = false) {
}