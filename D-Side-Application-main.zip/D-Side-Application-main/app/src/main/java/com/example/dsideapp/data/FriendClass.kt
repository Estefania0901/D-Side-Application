package com.example.dsideapp.data

data class FriendClass (
    val email : String? = "",
    val uid: String? = "",
    val userName : String? = ""
)


